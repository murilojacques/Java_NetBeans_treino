/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_integrador_mod_ii;

/**
 *
 * @author Murilo
 */
public class Projeto_Integrador_Mod_II {

    public static void main(String[] args) {
        Tela_Login tl = new Tela_Login();
        tl.setVisible(true);
    }
}
