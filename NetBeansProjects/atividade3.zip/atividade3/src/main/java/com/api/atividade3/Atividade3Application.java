package com.api.atividade3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade3Application {

	public static void main(String[] args) {
		SpringApplication.run(Atividade3Application.class, args);
	}

}
