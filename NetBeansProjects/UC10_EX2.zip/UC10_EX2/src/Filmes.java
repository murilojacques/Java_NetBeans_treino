/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Murilo
 */
public class Filmes {
    String filmeNome="";
    String filmeData="";
    String filmeCategoria="";

    public String getFilmeNome() {
        return filmeNome;
    }

    public void setFilmeNome(String filmeNome) {
        this.filmeNome = filmeNome;
    }

    public String getFilmeData() {
        return filmeData;
    }

    public void setFilmeData(String filmeData) {
        this.filmeData = filmeData;
    }

    public String getFilmeCategoria() {
        return filmeCategoria;
    }

    public void setFilmeCategoria(String filmeCategoria) {
        this.filmeCategoria = filmeCategoria;
    }
    
    
}
