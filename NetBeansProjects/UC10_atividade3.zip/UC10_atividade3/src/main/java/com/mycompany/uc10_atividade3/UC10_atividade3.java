/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.uc10_atividade3;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 *
 * @author Murilo
 */
public class UC10_atividade3 {

    public static void main(String[] args) {
        Tela_Inicial tela_inicial = new Tela_Inicial();
        tela_inicial.setVisible(true); 
    }
}
