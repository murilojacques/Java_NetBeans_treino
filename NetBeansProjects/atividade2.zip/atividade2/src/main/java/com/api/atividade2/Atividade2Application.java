package com.api.atividade2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade2Application {

	public static void main(String[] args) {
		SpringApplication.run(Atividade2Application.class, args);
	}

}
