/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio2;

import java.util.Scanner;

/**
 *
 * @author Murilo
 */
public class Exercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner variavel = new Scanner(System.in);
       Scanner vari = new Scanner(System.in);
       String a;
       int valor1, valor2;
       Transporte transporte1 = new Transporte();
       Hospedagem hospedagem1 = new Hospedagem();
       PacoteViagem pacoteviagem1 = new PacoteViagem();
       Venda venda1 = new Venda();
 
       System.out.println("Insira as informacoes relacionadas ao pacote de viagem ");
       System.out.println("\nInsira o destino da Viagem: ");
       pacoteviagem1.setDestino(variavel.nextLine());
       System.out.println("\ninsira a quantidade de dias de viagem: ");
       pacoteviagem1.setQdias(vari.nextInt());
       System.out.println("informe a margem de lucro do pacote de veagem: ");
       pacoteviagem1.setMargemlucro(vari.nextInt());
       System.out.println("informe o valor estimado de taxas adicionais: ");
       pacoteviagem1.setTaxadici(vari.nextInt());
       
       
        System.out.println("--------------------------------------------------------------------------------------------------------------------");
       
       System.out.println("\n\nInsira as informacoes sobre a hospedagem \n");
       System.out.println("Descricao da hospedagem: ");
       hospedagem1.setDescricao(variavel.nextLine());
       System.out.println("\nvalor da diaria da hospedagem (considere o valor em dolar): ");
       hospedagem1.setValordiaria(vari.nextInt());
       System.out.println( hospedagem1.getDescricao()+"  "+ hospedagem1.getValordiaria());
              
        System.out.println("--------------------------------------------------------------------------------------------------------------------");
 
        
       System.out.println("\n\nInsira as informacoes relacionadas ao transporte \n");
       
      do{
       System.out.println("digite o modo de trasnporte (aereo, maritimo, rodoviario, etc...): ");
       a = variavel.nextLine();
       transporte1.setTipo(a);
       switch(a){
           case "maritimo":
               transporte1.maritimo();
               break;
           case "aereo":
               transporte1.aereo();
               break;
           case "rodoviario":
               transporte1.rodoviario();
               break;
           case "ferroviario":
               transporte1.ferroviario();
               break;
           default :
               System.out.println("metodo de transporte invalido");
               break;
               
       }}while(!a.equals("maritimo")&& !a.equals("aereo")&& !a.equals("rodoviario")&& !a.equals("ferroviario") );
       
       System.out.println("\nDigite o valor do trasnporte (considere o valor em dolar): ");
       transporte1.setValor(vari.nextInt());
       transporte1.descrever();
       
       System.out.println("--------------------------------------------------------------------------------------------------------------------");
       System.out.println("--------------------------------------------------------------------------------------------------------------------");
       
       System.out.println("\n\nPacote de Viagem 1: \n");
       hospedagem1.descrever();
       System.out.println("tempo de estadia: "+pacoteviagem1.getQdias()+" dias");
       System.out.println("Valor total de hospedagem: $"+pacoteviagem1.thospedagem(hospedagem1.getValordiaria(), pacoteviagem1.getQdias()));
       System.out.println("Margem total de lucro: "+pacoteviagem1.valorlucro(pacoteviagem1.getMargemlucro(), pacoteviagem1.getTaxadici()));
       transporte1.descrever();
       System.out.println("Valor total do pacote de viagem: "+pacoteviagem1.tpacote(pacoteviagem1.thospedagem(hospedagem1.getValordiaria(), pacoteviagem1.getQdias()), transporte1.getValor(), pacoteviagem1.valorlucro(pacoteviagem1.getMargemlucro(), pacoteviagem1.getTaxadici())));
       
       
       
       System.out.println("\n\nPara a conversao de valor do pacote de viagem para Reais informe o valor do Dolar: ");
       venda1.setDolarReal(vari.nextInt());
       
       System.out.println("\n\n\n\nInsira seu nome: ");
       venda1.setNomecli(variavel.nextLine());
       System.out.println("Insira a forma de pagamento: ");
       venda1.setFormapaga(variavel.nextLine());
       System.out.println("\n\nVenda do pacote de viagem efetuada: ");
       
       venda1.descrever();
       hospedagem1.descrever();
       System.out.println("tempo de estadia: "+pacoteviagem1.getQdias()+" dias");
       System.out.println("Valor total de hospedagem: $"+pacoteviagem1.thospedagem(hospedagem1.getValordiaria(), pacoteviagem1.getQdias()));
       System.out.println("Margem total de lucro: "+pacoteviagem1.valorlucro(pacoteviagem1.getMargemlucro(), pacoteviagem1.getTaxadici()));
       transporte1.descrever();
       System.out.println("Valor total do pacote de viagem (considerado em dolar): "+pacoteviagem1.tpacote(pacoteviagem1.thospedagem(hospedagem1.getValordiaria(), pacoteviagem1.getQdias()), transporte1.getValor(), pacoteviagem1.valorlucro(pacoteviagem1.getMargemlucro(), pacoteviagem1.getTaxadici())));
       venda1.converterValor(pacoteviagem1.tpacote(pacoteviagem1.thospedagem(hospedagem1.getValordiaria(), pacoteviagem1.getQdias()), transporte1.getValor(), pacoteviagem1.valorlucro(pacoteviagem1.getMargemlucro(), pacoteviagem1.getTaxadici())), venda1.getDolarReal());
       
       //Murilo do futuro analisa a ordem que as info ta sendo inserida no codigo, ta meio bizzarro.//

    }
    
}
