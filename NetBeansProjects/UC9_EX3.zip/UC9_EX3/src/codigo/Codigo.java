package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Murilo
 */
public class Codigo {
    private String paciente=""; 
    private String CPF="";
    private String telefone="";
    private String data="";
    private String JPaciente="";
    private String ConRealizada="";

    public String getPaciente() {
        return paciente;
    }

    public void setPaciente(String paciente) {
        this.paciente = paciente;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getJPaciente() {
        return JPaciente;
    }

    public void setJPaciente(String JPaciente) {
        this.JPaciente = JPaciente;
    }

    public String getConRealizada() {
        return ConRealizada;
    }

    public void setConRealizada(String ConRealizada) {
        this.ConRealizada = ConRealizada;
    }
    
    
}
