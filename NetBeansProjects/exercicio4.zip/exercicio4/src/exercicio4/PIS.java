/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio4;

/**
 *
 * @author Murilo
 */
public class PIS extends Imposto {
    protected double debito=0;
    protected double credito=0;
    protected double Taxa=1.65;
    protected double Total=0;

    public double getDebito() {
        return debito;
    }

    public void setDebito(double debito) {
        this.debito = debito;
    }

   
    
    
    public void setCredito(double credito) {
        this.credito = credito;
    }

    public double getTotal() {
        return Total;
    }

    public void setTotal(double Total) {
        this.Total = Total;
    }

    

    

    
    public double getTaxa() {
        return Taxa;
    }

    public void setTaxa(double Taxa) {
        this.Taxa = Taxa;
    }

    

    
        
    public void Descrever(){
    
        System.out.println("O total a pagar e: "+ getTotal());
    }
    
    @Override
    public void CalculoImposto(){
    setTotal((float) ((debito-credito)*(Taxa/100)));
    
    
    }

    
}
