/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio4;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Murilo
 */
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner variavel = new Scanner(System.in);
        
        
        String tipoImposto="";
        
       
        Pagamentos valorPagamento = new Pagamentos();
        System.out.println("\nNome da Empresa: ");
        valorPagamento.setNomeEmpresa(variavel.nextLine());
        
        while(!tipoImposto.equals("pare")){
        System.out.println("\nPara parar a insercao de dados digite 'pare' abaixo");
        System.out.println("Informe o tipo de imposto (PIS/IPI): ");
        tipoImposto=variavel.nextLine();
        
        if(tipoImposto.equals("PIS")){  
        valorPagamento.PIS();
        }
        
        if(tipoImposto.equals("IPI")){
        
           valorPagamento.IPI();
        }
        }
        System.out.println("\n\nO nome da empresa: "+valorPagamento.getNomeEmpresa());
     for(int i=0; i<valorPagamento.Pagamento.size(); i++){
         
      System.out.println("\nO tipo de imposto e: "+ valorPagamento.tipo.get(i));   
     System.out.println("O total a pagar e de: "+ valorPagamento.Pagamento.get(i));
      
     }
    }
    
}
